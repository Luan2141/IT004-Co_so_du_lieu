import os
from lxml import etree
from tabulate import tabulate

# Hàm lấy path

def get_path(name_f):
    absolute_path = os.path.abspath(name_f)
    absolute_path = absolute_path.replace('\\', '/')
    return absolute_path

# Lấy path của folder XML

folder_path = get_path("XML")
if (os.path.exists(folder_path)):
    files = os.listdir(folder_path) # Lấy danh sách tất cả các file trong thư mục
    if (len(files)==0):
     print("\n[#] Folder XML rỗng !!!\n")
     exit()
else :
    print("\n[#] Folder XML chưa được tạo !!!\n")   
    exit() 

# Nhập input 

index = int(input("Chọn số thứ tự file trong folder XML (đếm từ trên xuống) từ 1 tới {} VD (1,2,3...): ".format(len(files)))) 

# Kiểm tra xem số thứ tự file trong folder có đúng không 

while (index <=0 or index > len(files)):
    print("\t[#] Chọn lại số thứ tự file !!!")
    index =  int(input("Chọn số thứ tự file trong folder XML (đếm từ trên xuống) từ 1 tới {} VD (1,2,3...): ".format(len(files)))) 

# In ra tên file và đọc file đó 
print ("Tên file đã chọn : {}".format(files[index-1]))
file_path = os.path.join(folder_path, files[index-1])
xml_file = open(file_path, "r")
xml_tree = etree.parse(xml_file)

# Nhập ngưỡng điểm

low_score = float(input("Nhập vào ngưỡng điểm thấp: "))
high_score = float(input("Nhập vào ngưỡng điểm cao: "))
while (low_score > high_score or low_score >10 or low_score <0 or high_score >10 or high_score <0):
    print("\t[#] Kiểm tra lại ngưỡng điểm nhập vào !!!")
    low_score = float(input("Nhập vào ngưỡng điểm thấp: "))
    high_score = float(input("Nhập vào ngưỡng điểm cao: "))
    
# Sử dụng XPath để lấy danh sách học sinh có điểm trung bình nằm trong khoảng từ low_score đến high_score có trong file

HS = xml_tree.xpath("//hoc_sinh[diem_tb >= %f and diem_tb <= %f]" % (low_score, high_score))

# In ra danh sách học sinh nằm trong ngưỡng điểm

data = []
check= False
for hoc_sinh in HS:
    ho_va_ten = hoc_sinh.xpath("ho_va_ten")[0].text
    diem_tb = hoc_sinh.xpath("diem_tb")[0].text
    ntns= hoc_sinh.xpath("ntns")[0].text 
    xeploai=hoc_sinh.xpath("xeploai")[0].text
    ket_qua = hoc_sinh.xpath("ket_qua")[0].text
    data.append([ho_va_ten,ntns,diem_tb,xeploai,ket_qua])
    check=True
if (check == False): # kiểm tra danh sách có rỗng hay không 
    data.append(["NULL", "NULL", "NULL", "NULL", "NULL"])
    
# Căn giữa toàn bộ cột trong bảng

headers = ["HỌ TÊN HỌC SINH","NTNS", "ĐIỂM TB","XẾP LOẠI","KẾT QUẢ"]
headers = [header.center(15) for header in headers] 
aligns = ["center", "center", "center", "center", "center"]
column_aligns = ["center", "center", "center", "center", "center"]

# Xuất danh sách học sinh dưới dạng bảng

print(tabulate(data, headers=headers, tablefmt="fancy_grid", numalign=aligns, colalign=column_aligns))
  
    