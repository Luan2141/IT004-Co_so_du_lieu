# Tạo danh sách tên trường

tentr_list=['THPT Bui Thi Xuan','THPT Trung Vuong','THPT Giong Ong To','THPT Nguyen Thi Minh Khai','THPT Le Quy Don','THPT Nguyen Trai','Pho thong Nang khieu the thao Olympic','THPT Hung Vuong','THPT Mac Dinh Chi','THPT Binh Phu','THPT Le Thanh Ton','THPT Luong Van Can','THPT Ngo Gia Tu','THPT Ta Quang Buu','THPT Nguyen Hue','THPT Nguyen Khuyen','THPT Nguyen Du','THPT Nguyen Hien','THPT Vo Truong Toan','THPT Thanh Da','THPT Vo Thi Sau','THPT Gia Dinh','THPT Phan Dang Luu','THPT Go Vap','THPT Nguyen Cong Tru','THPT Phu Nhuan','THPT Tan Binh','THPT Nguyen Chi Thanh','THPT Tran Phu','THPT Nguyen Thuong Hien','THPT Thu Duc','THPT Nguyen Huu Huan','THPT Tam Phu','THPT Cu Chi','THPT Quang Trung','THPT An Nhon Tay','THPT Trung Phu','THPT Trung Lap','THPT Nguyen Huu Cau','THPT Ly Thuong Kiet','THPT Binh Chanh','THPT Ten Lo Man','THPT Marie Curie','THPT Tran Khai Nguyen','THPT Nguyen An Ninh','THPT Nam Ky Khoi Nghia','THPT Nguyen Thai Binh','THPT Nguyen Trung Truc','THPT Han Thuyen','THPT Hoang Hoa Tham','THPT Thang Long','THPT Phuoc Long','THPT Ba Diem','THPT Tan Phong','THPT Truong Chinh','THPT Phu Hoa','THPT Tan Thong Hoi','THPT Tay Thanh','THPT Long Truong','THPT Nguyen Van Cu','THPT Nguyen Huu Tien','THPT Binh Khanh','THPT Can Thanh','THPT Tran Hung Dao','THPT Hiep Binh','Tieu hoc THCS va THPT Quoc Van Sai Gon','THPT Tran Quang Khai','THPT Vinh Loc','THPT Viet Au','THPT Viet Nhat','THPT Hung Dao','TH THCS THPT Chu Van An','Trung hoc Thuc hanh Dai hoc Su pham','Pho thong Nang Khieu DHQG Tp HCM','THPT Ly Thai To','THPT Tran Quoc Tuan','THPT An Duong Vuong','THPT Tran Nhan Tong','THPT Dong Duong','THPT Phuoc Kien','THPT Nhan Viet','THPT An Nghia','THPT Phu Lam','Trung hoc co so va trung hoc pho thong Phung Hung','THPT Nguyen Huu Canh','THPT Nguyen Van Linh','Phan hieu THPT Le Thi Hong Gam','THPT Nguyen Thi Dieu','THPT Quoc Tri','THPT Vinh Vien','THCS THPT Tran Cao Van','THPT Bach Viet','THPT Viet My Anh','THCS va THPT Nam Viet','THPT Van Lang','THPT Binh Hung Hoa','THPT Binh Tan','THPT Nguyen Tat Thanh','THPT Nguyen Van Tang','THPT Tran Van Giau']

# Tạo danh sách năm học   

namhoc_list =[]
for i in range(2014,2022):
    nien_khoa= str(i)+'-'+str(i+1)
    namhoc_list.append(nien_khoa)
  
# Nhập input

num_db = int(input("Nhập tên database (1:TRUONGHOC1 - 2:TRUONGHOC2): "))
while (num_db < 1 or num_db > 2):
    print("\t[#] Nhập lại tên database !!!")
    num_db = int(input("Nhập tên database (1:TRUONGHOC1 - 2:TRUONGHOC2) : "))

num_tr = int(input("Nhập tên trường (chọn từ 0 đến 99)): "))
while (num_tr <0 or num_tr > 99):
    print("\t[#] Nhập lại tên trường !!!")
    num_tr = int(input("Nhập tên trường (chọn từ 0 đến 99)): "))
print("Tên trường đã chọn: {}".format(tentr_list[num_tr])) 

nam_hoc = input("Nhập năm học và chọn trong khoảng năm học từ 2014-2015 đến 2021-2022 vd(2017-2018): ").rstrip() 
while (nam_hoc not in namhoc_list):
    print("\t[#] Nhập lại năm học!!!")
    nam_hoc = input("Nhập năm học và chọn trong khoảng năm học từ 2014-2015 đến 2021-2022 vd(2017-2018): ").rstrip()

xl_list =['Xuat sac','Gioi','Kha','Trung Binh','Yeu']    
num_xl = int(input("Nhập xếp loại học tập (0:Xuất sắc - 1:Giỏi - 2:Khá - 3:Trung bình - 4:Yếu ): "))
while (num_xl <0 or num_xl >4):
    print("\t[#] Nhập lại xếp loại!!!")
    num_xl = int(input("Nhập xếp loại học tập (0:Xuất sắc - 1:Giỏi - 2:Khá - 3:Trung bình - 4:Yếu ): "))

name_db = 'TRUONGHOC'+ str(num_db)    
ten_tr = tentr_list[num_tr]    
xep_loai=xl_list[num_xl]
name_file = (name_db + '-' + ten_tr + '-' + nam_hoc + '-' +xep_loai) + '.xml'

# Kết nối đến CSDL MySQL

password_MySQL =input("Nhập password MySQL: ")
import mysql.connector
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password= password_MySQL, 
  database= name_db
)

# Thực hiện truy vấn và đo thời gian thực hiện truy vấn

import time
mycursor = mydb.cursor()
start_time = time.time()
mycursor.execute("SELECT HS.HO, HS.TEN, HS.NTNS, HOC.DIEMTB, HOC.XEPLOAI, HOC.KQUA \n"
            f"FROM TRUONG, HS, HOC \n"
            f"WHERE TRUONG.TENTR = '{ten_tr}' \n"
            f"AND HOC.NAMHOC = '{nam_hoc}' \n"
            f"AND HOC.XEPLOAI= '{xep_loai}'\n"
            f"AND TRUONG.MATR = HOC.MATR \n"
            f"AND HS.MAHS = HOC.MAHS;")
result = mycursor.fetchall()
end_time = time.time()
elapsed_time = end_time - start_time

#  Tạo file XML và tạo danh sách học sinh

import xml.etree.ElementTree as ET
from tabulate import tabulate
table =[]
root = ET.Element("HS")
check= False # tạo biến check để kiểm tra 
for row in result:
    hoc_sinh = ET.SubElement(root, "hoc_sinh")
    ho_va_ten = ET.SubElement(hoc_sinh, "ho_va_ten")
    ho_va_ten.text = row[0] + " " + row[1]
    ntns = ET.SubElement(hoc_sinh, "ntns")
    ntns.text = str(row[2])
    diem_tb = ET.SubElement(hoc_sinh, "diem_tb")
    diem_tb.text = str(row[3])
    xeploai = ET.SubElement(hoc_sinh, "xeploai")
    xeploai.text = row[4]
    ket_qua = ET.SubElement(hoc_sinh, "ket_qua")
    ket_qua.text = row[5]
    table.append([ho_va_ten.text,ntns.text,diem_tb.text,xeploai.text,ket_qua.text])
    check= True  
xml_string = ET.tostring(root)
with open(name_file, "wb") as f:
    f.write(xml_string)
if(check == False): # Kiểm tra danh sách có trống hay không 
 table.append(["NULL","NULL","NULL","NULL","NULL"])
 
# Đóng kết nối với database

mydb.close() 

# Căn giữa toàn bộ cột trong bảng

headers = ["HỌ TÊN HỌC SINH","NTNS", "ĐIỂM TB","XẾP LOẠI","KẾT QUẢ"]
headers = [header.center(15) for header in headers]
aligns = ["center", "center", "center", "center", "center"]
column_aligns = ["center", "center", "center", "center", "center"]

# Xuất danh sách học sinh dưới dạng bảng và kết quả đo thời gian truy vấn 

print("\n","Database: " , name_db,"\n")
print(tabulate(table, headers=headers, tablefmt="fancy_grid", numalign=aligns, colalign=column_aligns))
print(f"\nThời gian truy vấn dữ liệu: {elapsed_time:.10f} giây\n") 

#tạo folder XML

import os
import shutil    

#tạo hàm lấy path 

def get_path(name_f):
    absolute_path = os.path.abspath(name_f).replace('\\', '/')
    return absolute_path

# hàm kiểm tra xem file đã tồn tại trong folder XML hay chưa. Nếu có thì in ra thông báo, nếu không thì thêm vào folder XML

def check_exist (name_file):
    folder_path = get_path('XML')
    file_path = os.path.join(folder_path, name_file)
    if os.path.exists(file_path):
        os.remove(get_path(name_file))
        print("File này đã tồn tại trong thư mục XML\n")
    else :
        shutil.move(get_path(name_file), get_path('XML'))

# kiểm tra xem folder XML được tạo chưa, nếu chưa thì tạo folder XML và thêm file vừa được tạo 

if os.path.exists(get_path('XML')):
    check_exist(name_file) # thực hiện hàm kiểm tra file   
else:
    os.mkdir('XML')
    shutil.move(get_path(name_file), get_path('XML'))
    
