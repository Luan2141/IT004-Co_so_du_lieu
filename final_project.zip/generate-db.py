import mysql.connector
import pandas as pd
import os
import random
import subprocess
import time
# Nhập password

password_MySQL = input("Nhập password MySQL: ")
start_time = time.time()

# Khởi tạo hàm lấy path và hàm thực thi

def get_path(name_file):
    absolute_path = os.path.abspath(name_file).replace('\\', '/')
    return absolute_path

def command(name_file,password_MySQL):
    path = get_path(name_file)
    command1 = [
        'mysql',
        '-uroot',
        '-p' + password_MySQL + '<' + path
    ]
    subprocess.run(command1, shell=True)

# Khởi tạo database truonghoc1 và truonghoc2

command("CreateSchema1.sql",password_MySQL)
command("CreateSchema2.sql",password_MySQL)

# Kết nối đến CSDL MySQL  

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password=password_MySQL,  
    database="truonghoc1" 
)
mycursor = mydb.cursor()

# Tạo danh sách mã trường, tên trường, địa chỉ trường 

matr_list = ['79000701','79000702','79000703','79000704','79000705','79000706','79000707','79000708','79000709','79000710','79000711','79000712','79000713','79000714','79000715','79000716','79000717','79000718','79000719','79000720','79000721','79000722','79000723','79000724','79000725','79000726','79000727','79000728','79000729','79000730','79000731','79000732','79000733','79000734','79000735','79000736','79000737','79000738','79000739','79000740','79000741','79000742','79000743','79000744','79000745','79000746','79000747','79000748','79000749','79000750','79000751','79000752','79000753','79000754','79000755','79000756','79000757','79000758','79000759','79000760','79000761','79000762','79000763','79000764','79000765','79000767','79000768','79000769','79000771','79000772','79000773','79000774','79000775','79000776','79000777','79000779','79000780','79000781','79000783','79000784','79000785','79000786','79000788','79000791','79000793','79000794','79000795','79000796','79000797','79000798','79000799','790007A1','790007A2','790007A4','790007A5','790007A6','790007A7','790007A8','790007A9','790007B0'] # Danh sách mã trường

tentr_list=['THPT Bui Thi Xuan','THPT Trung Vuong','THPT Giong Ong To','THPT Nguyen Thi Minh Khai','THPT Le Quy Don','THPT Nguyen Trai','Pho thong Nang khieu the thao Olympic','THPT Hung Vuong','THPT Mac Dinh Chi','THPT Binh Phu','THPT Le Thanh Ton','THPT Luong Van Can','THPT Ngo Gia Tu','THPT Ta Quang Buu','THPT Nguyen Hue','THPT Nguyen Khuyen','THPT Nguyen Du','THPT Nguyen Hien','THPT Vo Truong Toan','THPT Thanh Da','THPT Vo Thi Sau','THPT Gia Dinh','THPT Phan Dang Luu','THPT Go Vap','THPT Nguyen Cong Tru','THPT Phu Nhuan','THPT Tan Binh','THPT Nguyen Chi Thanh','THPT Tran Phu','THPT Nguyen Thuong Hien','THPT Thu Duc','THPT Nguyen Huu Huan','THPT Tam Phu','THPT Cu Chi','THPT Quang Trung','THPT An Nhon Tay','THPT Trung Phu','THPT Trung Lap','THPT Nguyen Huu Cau','THPT Ly Thuong Kiet','THPT Binh Chanh','THPT Ten Lo Man','THPT Marie Curie','THPT Tran Khai Nguyen','THPT Nguyen An Ninh','THPT Nam Ky Khoi Nghia','THPT Nguyen Thai Binh','THPT Nguyen Trung Truc','THPT Han Thuyen','THPT Hoang Hoa Tham','THPT Thang Long','THPT Phuoc Long','THPT Ba Diem','THPT Tan Phong','THPT Truong Chinh','THPT Phu Hoa','THPT Tan Thong Hoi','THPT Tay Thanh','THPT Long Truong','THPT Nguyen Van Cu','THPT Nguyen Huu Tien','THPT Binh Khanh','THPT Can Thanh','THPT Tran Hung Dao','THPT Hiep Binh','Tieu hoc THCS va THPT Quoc Van Sai Gon','THPT Tran Quang Khai','THPT Vinh Loc','THPT Viet Au','THPT Viet Nhat','THPT Hung Dao','TH THCS THPT Chu Van An','Trung hoc Thuc hanh Dai hoc Su pham','Pho thong Nang Khieu DHQG Tp HCM','THPT Ly Thai To','THPT Tran Quoc Tuan','THPT An Duong Vuong','THPT Tran Nhan Tong','THPT Dong Duong','THPT Phuoc Kien','THPT Nhan Viet','THPT An Nghia','THPT Phu Lam','Trung hoc co so va trung hoc pho thong Phung Hung','THPT Nguyen Huu Canh','THPT Nguyen Van Linh','Phan hieu THPT Le Thi Hong Gam','THPT Nguyen Thi Dieu','THPT Quoc Tri','THPT Vinh Vien','THCS THPT Tran Cao Van','THPT Bach Viet','THPT Viet My Anh','THCS va THPT Nam Viet','THPT Van Lang','THPT Binh Hung Hoa','THPT Binh Tan','THPT Nguyen Tat Thanh','THPT Nguyen Van Tang','THPT Tran Van Giau']

diachi_tr_list=['73 - 75 Bui Thi Xuan','3 Nguyen Binh Khiem','200/10 Nguyen Thi Dinh','275 Dien Bien Phu','110 Nguyen Thi Minh Khai Phuong 6 Quan 3 TP Ho Chi Minh','364 Nguyen Tat Thanh','Dai hoc The duc the thao TP Ho Chi Minh Khu pho 6 - phuong Linh Trung - Quan Thu Duc - TP.Ho Chi Minh','124 Hung Vuong','04 Tan Hoa Dong','102 Duong Tran Van Kieu Phuong 1 Quan 6 TPHCM','124 duong 17','173 Pham Hung','360E Ben Binh Dong','909 Ta Quang Buu','Duong Nguyen Van Tang Kp Chau Phuc Cam P.LTM Q9','50 Thanh Thai','XX-1 Dong Nai','3 Duong Dinh Nghe-P8-Q11','482 Duong Nguyen Thi Dang - Khu Pho 1','186 Nguyen Xi phuong 26 quan Binh Thanh TP HCM','95 Dinh Tien Hoang','195/29 Xo Viet Nghe Tinh','27 Nguyen Van Dau','90A Nguyen Thai Son','97 Quang Trung Phuong 8 Quan Go Vap TP.HCM','So 5 Hoang Minh Giam','19 Hoa Bang','1A Nguyen Hien Le','18 Le Thuc Hoach','544 Cach Mang Thang 8','166/24 Dang Van Bi','11 Doan Ket','31 Phu Chau Kp5','Tinh lo 8 Khu pho 1','Ap Phuoc An','227Duong Tinh lo 7 Ap Cho Cu Xa An Nhon Tay Huyen Cu Chi TP.HCM','1318 tinh lo 8 Ap 12','91/3 Trung Lap Ap Trung Binh ','To Ky Ap My Hue Xa Trung Chanh Huyen Hoc Mon TP.HCM ','Duong Nam Thoi 2 Ap Nam Thoi Xa Thoi Tam Thon','D17/1D Huynh Van Tri','8 Tran Hung Dao Phuong Pham Ngu Lao Quan 1 Tp.Ho Chi Minh','159 Nam Ky Khoi Nghia','225 Nguyen Tri Phuong','93 Tran Nhan Ton','269/8 Nguyen Thi Nho','913-915 Ly Thuong Kiet','9/168 Le Duc Tho','37 Dang Van Ngu','6 Hoang Hoa Tham','114-116 Hai Thuong Lan Ong','Duong Dinh Hoi Khu pho 6-Phuong Phuoc Long B-Q.9','So7 Nguyen Thi Soc Ap Bac Lanxa Ba Diem Huyen Hoc Mon','19F Nguyen Van Linh','1 DN11 Khu pho 4','So 25 duong Huynh Thi Bang Ap Phu Loi','Ap Bau Sim','27 Duong C2','309 Vo Van Hat Kp Phuoc Hiep phuong Long Truong Quan 9 Tp.Ho Chi Minh','100A ap 6 xa Xuan Thoi Thuong Huyen Hoc Mon','9A Ap 7','Ap Binh An','346 Duong Duyen Hai - Khu Pho Mieu Ba - Thi tran Can Thanh - huyen Can Gio','88/955E Le Duc Tho','So 63 duong Hiep Binh khu pho 6','300 Hoa Binh','343D Lac Long Quan','87 Duong So 3 Kdc Vinh Loc Phuong Binh Hung Hoa B Binh Tan TP.HCM','30/2 Quoc lo 1A','371 Nguyen Kiem','103 Nguyen Van Dau','So 7 Duong So 1 Khu Pho 1','280 An Duong Vuong Phuong 4 Quan 5 Tp Ho Chi Minh','153 Nguyen Chi Thanh','1/22/2a Nguyen Oanh','236/10-12 Thai Phien','duong so 3khu pho 6 phuong Truong Tho quan Thu Duc','66 Tan Hoa','114/37/12A-E Duong so 10','So 1163 Duong Le Van Luong Ap 3','41-39 Doan Hong Phuoc','Ap An Nghia','12-24 duong so 3 cho Phu Lam','14A Duong so 1 Phuong 16 Quan Go vap TP Ho Chi Minh','845 Huong Lo 2','So 02 Duong 3154 Pham The Hien Phuong 07 Quan 08','147 Pasteur','12 Tran Quoc Toan','313 Nguyen Van Luong','73/7 Le Trong Tan Phuong Son Ky Quan Tan Phu','126 To Hieu','653 Quoc lo 13 Kp3','252 Lac Long Quan','25 21/1-3 23/7-9 Duong Duc Hien','02-04 Tan Thanh','79/19 Duong So 4 Kp7 P BHH Q Binh Tan','117/4H Ho Van Long','249C Nguyen Van Luong','Duong so 1 KP Tai Dinh Cu Long Buu','203/40 Duong Truc Phuong 13 Quan Binh Thanh TP Ho Chi Minh']

# Chèn dữ liệu vào bảng TRUONG 

for i in range(100):
    matr = matr_list[i]
    tentr = tentr_list[i]
    diachi_tr = diachi_tr_list[i]
    mycursor.execute("INSERT INTO TRUONG (MATR, TENTR, DCHITR) VALUES('{}', '{}', '{}');\n".format(
        matr, tentr, diachi_tr))
    
# Đưa dữ liệu bảng TRUONG từ truonghoc1 sang truonghoc2

mycursor.execute(
    "INSERT INTO truonghoc2.TRUONG SELECT * FROM truonghoc1.TRUONG;\n")
mydb.commit()

# Tạo danh sách họ, tên, tên lót, địa chỉ 

ho =['Ly','Nguyen','Tran','Le','Pham','Hoang','Huynh','Phan','Vo','Dang','Bui','Do','Ho','Ngo','Duong','Lam','Dao','Doan','Vuon','Trinh','Dinh','Mai','To','Tang','Dong','Phung','Doan','Dong','Phi','Chau','Ha','Kieu','Luu','Ta','Thai','Thi','Tiet','Ton','Tong','Trang','Trieu','Truong','Uong','Van','Vi','Vien','Vinh','Xuan','Yen','Bach','Banh','Be','Bu','Cao','Cu','Cung','Cu','Dich','Doan','Dam','Dien','Dinh','Doan','Dong','Giang','Ham','Han','Hang','Han','Hang','Hau','Hieu','Hien','Hoa','Hoai','Hoan','Hong','Hop','Hung','Huong','Hy','Kha','Khoa','Khuong','Khu','Khuc','Khu','Khuu','Kim','Ky','Lai','Lac','La','Lang','Lang','Lap','Lenh','Lieu','Lo','Loc']

tenlot =['Anh','Bao','Bich','Chi','Cong','Cuc','Dan','Diep','Dinh','Doan','Duc','Giang','Ha','Hai','Hieu','Hoang','Hong','Hung','Huynh','Huyen','Khanh','Khai','Khanh','Khoa','Kiet','Kim','Lam','Lan','Linh','Long','Minh','My','Nam','Nga','Ngoc','Nha','Nhan','Nhat','Nhu','Pham','Phan','Phong','Phu','Phuong','Quang','Quyen','Quynh','Son','Thai','Thanh','Thao','Thi','Thien','Thieu','Thuy','Thuong','Tien','Trang','Tran','Trieu','Trinh','Trung','Truong','Tu','Tung','Tuan','Tuyet','Uyen','Van','Viet','Vinh','Vu','Xuan','Yen']

ten =['An','Anh','Binh','Cong','Chi','Dung','Duc','Dat','Diep','Dong','Gia','Hanh','Hien','Hoa','Hoai','Hong','Hung','Huy','Khanh','Khai','Khanh Linh','Khoi','Kim','Kien','Lan','Lam','Le','Linh','Long','Mai','Minh','My','Nam','Ngan','Ngoc','Nhan','Nhat','Nhi','Nhung','Oanh','Phat','Phong','Phuc','Phuong','Quan','Quang','Quynh','Son','Tam','Tan','Tan','Thanh','Thao','Thi','Thien','Thinh','Thu','Thuan','Thuy','Thuong','Tien','Tien','Tung','Tuyen','Tuyet','Uyen','Van','Viet','Vi','Vinh','Vui','Vinh','Xuan','Yen','Yen Nhi','Yen Trang','Yen Vy','Yen Xoi','Yen Do','Yen Oanh','Yen Thanh','Yen Chi','Yen Nhung','Yen Khanh','Yen Le','Yen Linh','Yen Phuong','Yen Hoa','Yen Huong','Yen Ngoc','Yen Mai','Yen Nhu','Yen Quynh','Yen Thao','Yen Van','Yen Vy','Yen Anh','Yen Hang','Yen Hien','Yen Thu','Yen Tien']

diachi = ['Ha Noi','Ho Chi Minh','Hai Phong','Da Nang','Can Tho','An Giang','Ba Ria - Vung Tau','Bac Giang','Bac Kan','Bac Lieu','Bac Ninh','Ben Tre','Binh Dinh','Binh Duong','Binh Phuoc','Binh Thuan','Ca Mau','Cao Bang','Dak Lak','Dak Nong','Dien Bien','Dong Nai','Dong Thap','Gia Lai','Ha Giang','Ha Nam','Ha Tinh','Hai Duong','Hau Giang','Hung Yen','Khanh Hoa','Kien Giang','Kon Tum','Lai Chau','Lam Dong','Lang Son','Lao Cai','Long An','Nam Dinh','Nghe An','Ninh Binh','Ninh Thuan','Phu Tho','Phu Yen','Quang Binh','Quang Nam','Quang Ngai','Quang Ninh','Quang Tri','Soc Trang','Son La','Tay Ninh','Thai Binh','Thai Nguyen','Thanh Hoa','Thua Thien Hue','Tien Giang','Tra Vinh','Tuyen Quang','Vinh Long','Vinh Phuc','Yen Bai','Phu Quoc']

# Chèn dữ liệu vào bảng HS

mahs_list = [] # Danh sách mã học sinh
ns_list = [] # Danh sách năm sinh 

for i in range(1000000):
    first_name = random.choice(ho) # Chọn họ
    last_name = random.choice(tenlot)+" "+random.choice(ten) # Chọn tên lót và tên 
    mahs_code  = '{:06}'.format(i)# Chọn mã học sinh
    mahs_list.append(mahs_code)
    id = '{:04}'.format(random.randint(0, 999)) + '{:06}'.format(i)# Chọn số CCCD
    ns = str(random.randint(2000, 2005))# Chọn năm sinh
    ns_list.append(ns)
    ths = str(random.randint(1, 12))# Chọn tháng sinh
    address = random.choice(diachi)# Chọn địa chỉ 

    # Kiểm tra ngày tháng năm sinh hợp lệ

    if (ths == 2):
        if (ns % 4 == 0) and (ns % 100 != 0 or ns % 400 == 0):
            ngs = str(random.randint(1, 29))
        else:
            ngs = str(random.randint(1, 28))
    elif (ths == 4 or ths == 6 or ths == 9 or ths == 11):
        ngs = str(random.randint(1, 30))
    else:
        ngs = str(random.randint(1, 31))

    ntns = ngs.zfill(2) + "/" + ths.zfill(2) + "/" + ns # Tạo ngày tháng năm sinh 
    mycursor.execute("INSERT INTO HS (MAHS, HO, TEN, CCCD, NTNS, DCHI_HS) VALUES ('{}','{}','{}','{}','{}','{}');\n".format(
        mahs_code, first_name, last_name, id, ntns, address))
    
# Đưa dữ liệu bảng HS từ truonghoc1 sang truonghoc2    

mycursor.execute("INSERT INTO truonghoc2.HS SELECT * FROM truonghoc1.HS;\n")
mydb.commit()

# Chèn dữ liệu vào bảng HOC

for i in range(1000000):
    count = random.randint(1, 3) # Chọn ngẫu nhiên cho mỗi HS trong bảng HOC từ 1 tới 3 dòng 
    mash_cur = mahs_list[i] # Lấy mã học sinh
    nam_nhap_hoc = (int(ns_list[i]) + 14) # Tạo năm nhập học 
    matr_cur = random.choice(matr_list) # Chọn mã trường 
    for j in range(count): 
        namhoc_begin = nam_nhap_hoc + j
        namhoc_end = namhoc_begin + 1
        nien_khoa = str(namhoc_begin) + "-" + str(namhoc_end)# Tạo niên khóa 
        gpa = round(random.randint(0, 9) + random.random() * 0.9, 2)# Tạo điểm trung bình
        # Tạo xếp loại và kết quả 
        if (gpa >= 9):
            xeploai = "Xuat sac"
        elif (gpa >= 8):
            xeploai = "Gioi"
        elif (gpa >= 6.5):
            xeploai = "Kha"
        elif (gpa >= 5):
            xeploai = "Trung binh"
        else:
            xeploai = "Yeu"

        if (gpa >= 5):
            ketqua = "Hoan thanh"
        else:
            ketqua = "Chua hoan thanh"
        mycursor.execute("INSERT INTO HOC (MATR, MAHS, NAMHOC, DIEMTB, XEPLOAI, KQUA) VALUES ('{}','{}','{}','{}','{}','{}');\n".format(
            matr_cur, mash_cur, nien_khoa, gpa, xeploai, ketqua))
        
# Đưa dữ liệu bảng HOC từ truonghoc1 sang truonghoc2          

mycursor.execute("INSERT INTO truonghoc2.HOC SELECT * FROM truonghoc1.HOC;\n")
mydb.commit()

# Đóng kết nối với database   

mydb.close()

# In thông báo và thời gian thực hiện

print("\nDONE")
end_time = time.time()
elapsed_time = (end_time - start_time)*1.0/60
print(f"\nThời gian thực hiện : {elapsed_time:.10f} phút\n")
