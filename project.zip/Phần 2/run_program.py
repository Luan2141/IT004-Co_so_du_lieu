# import some lib
import pandas as pd
import numpy as np
import os
from unidecode import unidecode


#read lookup data
tb_cap = pd.read_excel('Data/table_Cap.xlsx')
tb_lh = pd.read_excel('Data/table_loaiHinh.xlsx')
tb_lt = pd.read_excel('Data/table_loaiTruong.xlsx')
tb_pgddt = pd.read_excel('Data/table_PhongGDDT.xlsx')
tb_sgddt = pd.read_excel('Data/table_SoGDDT.xlsx')
#read data
gdtx = pd.read_excel('Data/data_gdtx.xlsx')
mn = pd.read_excel('Data/data_mn.xlsx')
th = pd.read_excel('Data/data_th.xlsx')
thcs = pd.read_excel('Data/data_thcs.xlsx')
thpt = pd.read_excel('Data/data_thpt.xlsx')

#create dictionary
dcap = {}
dlh = {}
dlt = {}
dpgddt = {}
dsgddt ={}


#insert all the table
def instb(data, f, name_col, dict, name_tb ):
    for index, row in data.iterrows():
        ma = str(row['MA_' + name_col])
        ten = str(row['TEN_' + name_col])
        if(ten == 'nan'):
            ten = 'NULL'
            f.write('INSERT INTO {} VALUES ("{}", NULL);\n'.format(name_tb, ma))
        else:
            f.write('INSERT INTO {} VALUES ("{}", "{}");\n'.format(name_tb, ma, ten))
        dict[ten] = ma

#insert tables
def tables():
    f = open('Data/table_Cap.sql', 'w', encoding = 'utf-8')
    f.write('USE truonghoc;\n')
    instb(tb_cap, f, 'CAP', dcap, 'Cap')
    f.close()

    f = open('Data/table_Loaitruong.sql', 'w', encoding = 'utf-8')
    f.write('USE truonghoc;\n')
    instb(tb_lt, f, 'LT', dlt, 'LoaiTruong')
    f.close()

    f = open('Data/table_LoaiHinh.sql', 'w', encoding = 'utf-8')
    f.write('USE truonghoc;\n')
    instb(tb_lh, f, 'LH', dlh, 'loaiHinh')
    f.close()

    f = open('Data/table_PhongGDDT.sql', 'w', encoding = 'utf-8')
    f.write('USE truonghoc;\n')
    instb(tb_pgddt, f, 'PHG', dpgddt, 'PhongGDDT')
    f.close()
    
    f = open('Data/table_SoGDDT.sql', 'w', encoding = 'utf-8')
    f.write('USE truonghoc;\n')
    instb(tb_sgddt,f,'SO',dsgddt, 'SoGDDT')
    f.close()

#insert to main table
def ins(arr, name, cap):
    with open('Data/' + name + '.sql', 'w', encoding='utf-8') as f:
        f.write('USE truonghoc;\n')
        for index, row in arr.iterrows():
            sgddt = 'HCM'
            ma = str(row['ma_truong'])
            ten = str(row['ten_truong'])
            dc = str(row['dia_chi']) 
            
            if(dc == 'nan'):
                dc = 'Không có'
            lh = str(row['loai_hinh'])
            if(lh == 'nan'):
                lh = 'NULL'
            lh = dlh[lh]
            lt = str(row['loai_truong'])
            if(lt == 'nan'):
                lt = 'NULL'
            lt = dlt[lt]
            pgddt = str(row['phong_gddt'])
            if(pgddt == 'nan'):
                pgddt = 'NULL'
            pgddt = dpgddt[pgddt]
            f.write('INSERT INTO danhsachtruong VALUES ("{}", "{}", "{}", "{}", "{}", "{}", "{}","{}");\n'.format(ma, ten, dc, lh, lt,sgddt, pgddt, cap))
        f.close()

tables() 
ins(gdtx, 'data_gdtx', 'GDTX')
ins(mn, 'data_mn', 'MN')
ins(th, 'data_th', 'TH')
ins(thcs, 'data_thcs', 'THCS')
ins(thpt, 'data_thpt', 'THPT')