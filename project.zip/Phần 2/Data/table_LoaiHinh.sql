USE truonghoc;
INSERT INTO loaiHinh VALUES ("XXXXX", NULL);
INSERT INTO loaiHinh VALUES ("CL", "Công lập");
INSERT INTO loaiHinh VALUES ("TT", "Tư thục");
INSERT INTO loaiHinh VALUES ("DL", "Dân lập");
