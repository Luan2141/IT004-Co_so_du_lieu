USE truonghoc;
INSERT INTO Cap VALUES ("GDTX", "Giáo dục thường xuyên");
INSERT INTO Cap VALUES ("MN", "Mầm non");
INSERT INTO Cap VALUES ("TH", "Tiểu học");
INSERT INTO Cap VALUES ("THCS", "Trung học cơ sở");
INSERT INTO Cap VALUES ("THPT", "Trung học phổ thông");
