USE truonghoc;
INSERT INTO SoGDDT VALUES ("HCM", "Sở Giáo dục và Đào tạo Hồ Chí Minh");
