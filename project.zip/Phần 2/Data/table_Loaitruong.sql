USE truonghoc;
INSERT INTO LoaiTruong VALUES ("XXXXXX", NULL);
INSERT INTO LoaiTruong VALUES ("TTGDTX", "TT GDTX");
INSERT INTO LoaiTruong VALUES ("TTGDNN", "TT GDNN");
INSERT INTO LoaiTruong VALUES ("GDNNTX", "TT GDNN - GDTX");
INSERT INTO LoaiTruong VALUES ("PTHONG", "Trường phổ thông");
INSERT INTO LoaiTruong VALUES ("DANTOC", "Dân tộc bán trú");
INSERT INTO LoaiTruong VALUES ("NKTDTT", "Năng khiếu thể dục thể thao");
INSERT INTO LoaiTruong VALUES ("CHUYEN", "Trường chuyên");
